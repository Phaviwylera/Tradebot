# BTC 5-minute paper bot

Paper-trading bot for Polymarket's BTC 5-minute Up/Down markets. Simulated money only. No wallet, no keys.

## Deploy on Vercel
1. Push this folder to a GitHub repository.
2. In Vercel: Add New > Project > import the repository. Leave all settings at default (no framework, no build command).
3. Deploy. `vercel.json` relays Polymarket's public data so the browser can read it.

## Run locally
Open `index.html` through any local server, or deploy to Vercel. The page calls `/gamma/...` and `/clob/...`, which `vercel.json` forwards to Polymarket.

Never add a private key or API secret to this page. Anything in a hosted page is public.
